package com.attendance.swipe.controllers;

import com.attendance.swipe.model.EmployeeTime;
import com.attendance.swipe.service.EmployeeTimeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/employee")
public class EmployeeTimeController {
    @Autowired
    private EmployeeTimeService employeeTimeService;

    @GetMapping("/clock-in/{employeeId}")
    public void clockIn(@PathVariable Long employeeId) {
        employeeTimeService.clockIn(employeeId);
    }

    @GetMapping("/clock-out/{employeeId}")
    public void clockOut(@PathVariable Long employeeId) {
        employeeTimeService.clockOut(employeeId);
    }

    @GetMapping("/employeesTime/{date}")
    public List<EmployeeTime> getEmployeesTimeForDay(@PathVariable String date) {
        return employeeTimeService.getEmployeesTimeForDay(date);
    }


}
