package com.attendance.swipe.model;

public enum EventType {
    CLOCK_IN,
    CLOCK_OUT
}

