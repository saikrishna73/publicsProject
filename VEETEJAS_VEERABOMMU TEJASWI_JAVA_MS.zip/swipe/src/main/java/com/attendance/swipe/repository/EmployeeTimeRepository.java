package com.attendance.swipe.repository;

import com.attendance.swipe.model.EmployeeTime;
import com.attendance.swipe.model.TimeEvent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EmployeeTimeRepository extends JpaRepository<EmployeeTime, Long> {

    @Query("select et from EmployeeTime et where et.employeeId=:employeeId and et.date=:date")
    public EmployeeTime findByEmployeeId(@Param("employeeId") Long employeeId, @Param("date") String date);
    @Query("select et from EmployeeTime et where et.date=:date")
    public List<EmployeeTime> findByEmployeesDate( @Param("date") String date);
}

