package com.attendance.swipe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SwipeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SwipeApplication.class, args);
	}

}
