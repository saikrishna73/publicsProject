package com.attendance.swipe.service;

import com.attendance.swipe.model.EmployeeTime;
import com.attendance.swipe.model.EventType;
import com.attendance.swipe.model.TimeEvent;
import com.attendance.swipe.repository.EmployeeTimeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class EmployeeTimeService {
    @Autowired
    private EmployeeTimeRepository employeeTimeRepository;

    public void clockIn(Long employeeId) {
        EmployeeTime employeeTime = getOrCreateEmployeeTime(employeeId);
        TimeEvent timeEvent = new TimeEvent();
        timeEvent.setTimestamp(LocalDateTime.now());
        timeEvent.setEventType(EventType.CLOCK_IN);
        employeeTime.getTimeEvents().add(timeEvent);
        employeeTimeRepository.save(employeeTime);
    }

    public void clockOut(Long employeeId) {
        EmployeeTime employeeTime = getOrCreateEmployeeTime(employeeId);
        TimeEvent timeEvent = new TimeEvent();
        timeEvent.setTimestamp(LocalDateTime.now());
        timeEvent.setEventType(EventType.CLOCK_OUT);
        employeeTime.getTimeEvents().add(timeEvent);
        employeeTimeRepository.save(employeeTime);
    }

    private EmployeeTime getOrCreateEmployeeTime(Long employeeId) {
        EmployeeTime employeeTime = employeeTimeRepository.findByEmployeeId(employeeId,
                LocalDateTime.now().toLocalDate().toString());
        if (employeeTime == null) {
            employeeTime = new EmployeeTime();
            employeeTime.setEmployeeId(employeeId);
            employeeTime.setDate(LocalDateTime.now().toLocalDate().toString());
        }
        return employeeTime;
    }

    public List<EmployeeTime> getEmployeesTimeForDay(String date) {
        return employeeTimeRepository.findByEmployeesDate(date);
    }
}


