package com.attendance.notificationService.service;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.Arrays;

@Service
public class KafkaConsumer {

    private final EmailService emailService;

    public KafkaConsumer(EmailService emailService) {
        this.emailService = emailService;
    }

    @KafkaListener(topics = "low-hours-topic", groupId = "notification-group")
    public void receiveLowHoursNotification(String message) {
        // Parse the message
        String[] parts = message.split(",");
        String employeeId = parts[0];
        String totalHours = parts[1];
        String dateString = parts[2];
        LocalDate date = LocalDate.parse(dateString);

        // Create and send the email
        String to = "vbnikhil10@gmail.com"; // Replace with the actual employee email
        String subject = "Low Attendance Notification";
        String text = String.format("Dear Employee,\n\nYour total hours on %s were %s, which is below 4 hours. Please take necessary actions.", date, totalHours);

        emailService.sendNotificationEmail(to, subject, text);
    }
}

