package com.attendance.retrivalService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RetrivalServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RetrivalServiceApplication.class, args);
	}

}
