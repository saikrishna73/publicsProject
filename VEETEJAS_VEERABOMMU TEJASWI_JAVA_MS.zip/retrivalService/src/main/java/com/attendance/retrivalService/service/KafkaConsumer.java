package com.attendance.retrivalService.service;

import com.attendance.retrivalService.model.TotalHours;
import com.attendance.retrivalService.repository.TotalHoursRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
public class KafkaConsumer {

    private final TotalHoursRepository totalHoursRepository;

    @Autowired
    public KafkaConsumer(TotalHoursRepository totalHoursRepository) {
        this.totalHoursRepository = totalHoursRepository;
    }

    @KafkaListener(topics = "total-hours-topic", groupId = "mongodb-consumer-group")
    public void receiveTotalHours(String message) {
        // Parse the message
        String[] parts = message.split(",");
        Long employeeId = Long.parseLong(parts[0]);
        String totalHours = parts[1];
        LocalDate date = LocalDate.parse(parts[2]);

        // Store in MongoDB
        TotalHours totalHoursEntity = new TotalHours();
        totalHoursEntity.setEmployeeId(employeeId);
        totalHoursEntity.setTotalHours(totalHours);
        totalHoursEntity.setDate(date);

        totalHoursRepository.save(totalHoursEntity);
    }
}

