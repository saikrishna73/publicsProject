package com.attendance.retrivalService.Controller;

import com.attendance.retrivalService.model.TotalHours;
import com.attendance.retrivalService.repository.TotalHoursRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

    private final TotalHoursRepository totalHoursRepository;

    @Autowired
    public EmployeeController(TotalHoursRepository totalHoursRepository) {
        this.totalHoursRepository = totalHoursRepository;
    }

    @GetMapping("/total-hours/{employeeId}/{date}")
    public String getTotalHours(@PathVariable Long employeeId, @PathVariable String date) {
        LocalDate localDate = LocalDate.parse(date);
        TotalHours totalHours = totalHoursRepository.findByEmployeeIdAndDate(employeeId, localDate);

        return totalHours != null ? totalHours.getTotalHours() : "data does not exist for that date and employee";
    }
}

