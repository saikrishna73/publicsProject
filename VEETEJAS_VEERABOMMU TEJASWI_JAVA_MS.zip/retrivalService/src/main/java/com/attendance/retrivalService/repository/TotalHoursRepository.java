package com.attendance.retrivalService.repository;

import com.attendance.retrivalService.model.TotalHours;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.time.LocalDate;

public interface TotalHoursRepository extends MongoRepository<TotalHours, String> {
    TotalHours findByEmployeeIdAndDate(Long employeeId, LocalDate date);
}

