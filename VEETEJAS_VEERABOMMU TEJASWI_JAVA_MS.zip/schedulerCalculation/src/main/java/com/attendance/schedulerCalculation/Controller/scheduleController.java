package com.attendance.schedulerCalculation.Controller;

import com.attendance.schedulerCalculation.scheduler.DailyScheduler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/attendanceTest")
public class scheduleController {
    @Autowired
    private DailyScheduler dailyScheduler;

    @GetMapping("/schedulerRun")
    public void schedulerRun() {
        dailyScheduler.calculateAndPublishTotalHours();
    }

}
