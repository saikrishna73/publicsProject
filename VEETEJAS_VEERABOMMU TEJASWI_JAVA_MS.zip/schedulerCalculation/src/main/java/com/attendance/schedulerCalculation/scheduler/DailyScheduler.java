package com.attendance.schedulerCalculation.scheduler;

import com.attendance.schedulerCalculation.messaging.KafkaProducer;
import com.attendance.schedulerCalculation.model.EmployeeTime;
import com.attendance.schedulerCalculation.model.EventType;
import com.attendance.schedulerCalculation.model.TimeEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

@Component
public class DailyScheduler {


    @Autowired
    private KafkaProducer kafkaProducer;

    @Autowired
    private RestTemplate restTemplate;

    @Scheduled(cron = "0 0 0 * * ?") // Trigger every day at midnight
    public void calculateAndPublishTotalHours() {
        // Retrieve all employees and calculate total hours for each
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        HttpEntity<String> entity = new HttpEntity<String>(headers);
        String date = LocalDateTime.now().minusDays(1).toLocalDate().toString();
        EmployeeTime[] employeesTime = restTemplate.exchange("http://localhost:8080/employee/employeesTime/"+
        date, HttpMethod.GET, entity, EmployeeTime[].class).getBody();

        for (EmployeeTime employeeTime : employeesTime) {
            long totalHours = calculateTotalHours(employeeTime);
            String employeeId = String.valueOf(employeeTime.getEmployeeId());

            kafkaProducer.sendTotalHours(employeeId, String.valueOf(totalHours/60+":"+totalHours%60), date);

            if (totalHours/60 < 4) {
                kafkaProducer.sendLowHours(employeeId, String.valueOf(totalHours/60+":"+totalHours%60), date);
            }
        }
    }

    private long calculateTotalHours(EmployeeTime employeeTime) {
       List<TimeEvent> te= employeeTime.getTimeEvents().stream().sorted(Comparator.comparing(TimeEvent::getTimestamp)).
                                toList();
       long totalTime = 0;
       boolean timeIn = false;
        LocalDateTime startTime  = null;
       for(TimeEvent t: te){

           if(!timeIn && t.getEventType().equals(EventType.CLOCK_IN)){
               timeIn = true;
               startTime = t.getTimestamp();
           }

           if(timeIn && t.getEventType().equals(EventType.CLOCK_OUT)){
               timeIn = false;
               totalTime = totalTime+ startTime.until(t.getTimestamp(), ChronoUnit.MINUTES);
           }
       }
        return totalTime;
    }
}

