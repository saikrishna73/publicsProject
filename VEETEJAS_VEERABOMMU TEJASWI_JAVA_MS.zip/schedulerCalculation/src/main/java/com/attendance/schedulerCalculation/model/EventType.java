package com.attendance.schedulerCalculation.model;

public enum EventType {
    CLOCK_IN,
    CLOCK_OUT
}

