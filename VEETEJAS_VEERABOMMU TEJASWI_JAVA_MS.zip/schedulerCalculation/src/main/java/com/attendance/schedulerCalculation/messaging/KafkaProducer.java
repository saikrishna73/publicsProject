package com.attendance.schedulerCalculation.messaging;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

@Component
public class KafkaProducer {

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    public void sendTotalHours(String employeeId, String totalHours, String date) {
        String message = String.format("%s,%s,%s", employeeId, totalHours, date);
        kafkaTemplate.send("total-hours-topic", message);
    }

    public void sendLowHours(String employeeId, String totalHours, String date) {
        String message = String.format("%s,%s,%s", employeeId, totalHours, date);
        kafkaTemplate.send("low-hours-topic", message);
    }
}
