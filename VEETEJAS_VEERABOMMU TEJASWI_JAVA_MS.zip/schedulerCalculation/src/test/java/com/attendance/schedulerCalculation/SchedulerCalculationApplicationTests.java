package com.attendance.schedulerCalculation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchedulerCalculationApplicationTests {

	@Test
	void contextLoads() {
	}

}
